# SPDX-License-Identifier: MIT
"""Video add-on shortcuts and the StreamSelect Home PIN prompt."""

import hashlib
import hmac
import json
import re
import secrets
import tempfile
import time
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

SHORTCUTS = (
    ('xStream', 'plugin.video.xstream'),
    ('xShip', 'plugin.video.xship'),
    ('xVAULT', 'plugin.video.xvault'),
)
ADULTS = 'Erwachsenenbereich'
CUMINATION = 'plugin.video.cumination'
ROUNDS = 600_000
MAX_ATTEMPTS = 5
LOCK_SECONDS = 60


class HomePanel(xbmcgui.WindowXMLDialog):
    def onInit(self):
        try:
            for index, label in enumerate(self.labels, 200):
                self.getControl(index).setLabel(label)
        except RuntimeError:
            self.ready = False
            self.close()

    def onClick(self, control_id):
        index = control_id - 200
        if 0 <= index < len(self.labels):
            self.choice = index
            self.close()
        elif control_id == 219:
            self.close()


def choose(dialog, title, labels, layout):
    if xbmc.getSkinDir() in ('skin.streamselect.home', 'skin.streamselect'):
        window = None
        try:
            window = HomePanel(layout, xbmcaddon.Addon().getAddonInfo('path'), 'Default', '1080i')
            window.labels = labels
            window.choice = -1
            window.ready = True
            window.doModal()
            if window.ready:
                return window.choice
        except RuntimeError as error:
            xbmc.log('StreamSelect Home: %s' % error, xbmc.LOGWARNING)
        finally:
            del window
    return dialog.select(title, labels)


def show_extensions(enabled, open_addon):
    dialog = xbmcgui.Dialog()
    labels = [name if enabled(addon_id) else name + ' (nicht aktiv)' for name, addon_id in SHORTCUTS]
    choice = choose(dialog, 'Zusätzliche Video-Add-ons', labels + [ADULTS + ' (PIN)'],
                    'script-streamselect-extensions.xml')
    if 0 <= choice < len(SHORTCUTS):
        open_addon(SHORTCUTS[choice][1])
    elif choice == len(SHORTCUTS):
        show_adults(dialog, enabled, open_addon)


def input_pin(dialog, heading):
    return dialog.input(heading, type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)


def pin_hash(pin, salt):
    return hashlib.pbkdf2_hmac('sha256', pin.encode('ascii'), bytes.fromhex(salt), ROUNDS).hex()


def save_pin_state(path, state):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent, delete=False) as file:
        pending = Path(file.name)
        try:
            json.dump(state, file)
            file.close()
            pending.replace(path)
        finally:
            pending.unlink(missing_ok=True)


def set_pin(path, dialog):
    pin = input_pin(dialog, 'Neue PIN festlegen (4–8 Ziffern)')
    if not pin:
        return False
    if not re.fullmatch('[0-9]{4,8}', pin):
        dialog.ok(ADULTS, 'Die PIN muss aus 4 bis 8 Ziffern bestehen.')
        return False
    if input_pin(dialog, 'Neue PIN wiederholen') != pin:
        dialog.ok(ADULTS, 'Die PIN wurde nicht bestätigt.')
        return False
    salt = secrets.token_hex(16)
    save_pin_state(path, {'salt': salt, 'hash': pin_hash(pin, salt), 'attempts': 0, 'locked_until': 0})
    return True


def unlock(path, dialog):
    try:
        state = json.loads(path.read_text(encoding='utf-8'))
    except FileNotFoundError:
        return set_pin(path, dialog)
    now = time.time()
    locked_until = state['locked_until']
    if now < locked_until:
        dialog.ok(ADULTS, 'Zu viele Fehlversuche. Warte bitte %d Sekunden.' % (int(locked_until - now) + 1))
        return False
    pin = input_pin(dialog, 'PIN für den Erwachsenenbereich eingeben')
    if not pin:
        return False
    valid = bool(re.fullmatch('[0-9]{4,8}', pin)) and hmac.compare_digest(
        state['hash'], pin_hash(pin, state['salt'])
    )
    attempts = 0 if valid else (0 if locked_until else state['attempts']) + 1
    locked = attempts >= MAX_ATTEMPTS
    state.update(attempts=attempts, locked_until=time.time() + LOCK_SECONDS if locked else 0)
    save_pin_state(path, state)
    if not valid:
        dialog.ok(ADULTS, 'Zu viele Fehlversuche. Warte bitte 60 Sekunden.' if locked else 'Die PIN ist falsch.')
    return valid


def show_adults(dialog, enabled, open_addon):
    profile = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')))
    path = profile / 'adult-pin.json'
    if not unlock(path, dialog):
        return
    label = 'Cumination öffnen' if enabled(CUMINATION) else 'Cumination (nicht aktiv)'
    choice = choose(dialog, ADULTS, [label, 'PIN ändern'], 'script-streamselect-adults.xml')
    if choice == 0:
        open_addon(CUMINATION)
    elif choice == 1 and set_pin(path, dialog):
        dialog.ok(ADULTS, 'Die PIN wurde geändert.')
