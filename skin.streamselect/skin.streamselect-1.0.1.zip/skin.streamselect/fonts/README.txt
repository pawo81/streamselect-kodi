The skin uses the default Arial font provided by Kodi.
