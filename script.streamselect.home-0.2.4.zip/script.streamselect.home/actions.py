# SPDX-License-Identifier: MIT
"""StreamSelect Home launcher and skin actions for Kodi 21."""
import sys
from urllib.parse import parse_qs, urlencode
import xbmc
import xbmcaddon
import xbmcgui

TITLE = 'StreamSelect Home'
TMDB = 'plugin.video.themoviedb.helper'
SHORTCUTS = [('StreamSelect', 'plugin.video.xstreamship'), ('xStream', 'plugin.video.xstream'),
             ('xShip', 'plugin.video.xship'), ('xVault', 'plugin.video.xvault'),
             ('MovieScout', 'plugin.video.moviescout'), ('TMDb Helper', TMDB)]


def enabled(addon_id):
    return xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % addon_id)


def open_addon(addon_id):
    if not enabled(addon_id):
        xbmcgui.Dialog().ok(TITLE, 'Diese Erweiterung ist nicht installiert oder nicht aktiviert: ' + addon_id)
        return
    xbmc.executebuiltin('ActivateWindow(Videos,plugin://%s/,return)' % addon_id)


def local_library():
    return xbmc.getCondVisibility('Skin.HasSetting(SS.LocalLibrary)') or not enabled(TMDB)


def browse(kind):
    if local_library():
        path = 'videodb://movies/titles/' if kind == 'movie' else 'videodb://tvshows/titles/'
    else:
        path = 'plugin://%s/?info=popular&tmdb_type=%s' % (TMDB, kind)
    xbmc.executebuiltin('ActivateWindow(Videos,%s,return)' % path)


def search():
    index = xbmcgui.Dialog().select('Suche', ['Filme auf TMDb suchen', 'Serien auf TMDb suchen', 'Lokale Filme durchsuchen'])
    if index < 0:
        return
    if index < 2:
        if not enabled(TMDB):
            xbmcgui.Dialog().ok(TITLE, 'Für die Online-Suche bitte TMDb Helper installieren und aktivieren.')
            return
        kind = 'movie' if index == 0 else 'tv'
        heading = 'Filmtitel suchen' if kind == 'movie' else 'Serientitel suchen'
        query = xbmcgui.Dialog().input(heading).strip()
        if not query:
            return
        params = urlencode({'info': 'search', 'tmdb_type': kind, 'query': query, 'history': 'true'})
        xbmc.executebuiltin('ActivateWindow(Videos,plugin://%s/?%s,return)' % (TMDB, params))
    else:
        from legacy import choose_movies
        query = xbmcgui.Dialog().input('Lokalen Filmtitel suchen').strip()
        if query:
            choose_movies({'filter': {'field': 'title', 'operator': 'contains', 'value': query}}, 'Suchergebnisse')


def addons():
    labels = [name + ('' if enabled(addon_id) else ' (nicht aktiv)') for name, addon_id in SHORTCUTS]
    index = xbmcgui.Dialog().select('Deine Video-Add-ons', labels + ['Alle Video-Add-ons'])
    if index < 0:
        return
    if index == len(SHORTCUTS):
        xbmc.executebuiltin('ActivateWindow(Videos,addons://sources/video/,return)')
    else:
        open_addon(SHORTCUTS[index][1])


def more():
    choices = [('Musik', 'Music'), ('Live-TV', 'TVChannels'), ('Radio', 'RadioChannels'),
               ('Bilder', 'Pictures'), ('Dateimanager', 'FileManager'),
               ('Add-on-Verwaltung', 'AddonBrowser'), ('Kodi-Profile', 'Profiles')]
    index = xbmcgui.Dialog().select('Weitere Kodi-Bereiche', [item[0] for item in choices])
    if index >= 0:
        xbmc.executebuiltin('ActivateWindow(%s)' % choices[index][1])


def main():
    action = parse_qs('&'.join(sys.argv[1:])).get('action', [''])[0]
    if action == 'movies':
        browse('movie')
    elif action == 'tvshows':
        browse('tv')
    elif action == 'search':
        search()
    elif action == 'addons':
        addons()
    elif action == 'streamselect':
        open_addon('plugin.video.xstreamship')
    elif action == 'tmdb_settings':
        if enabled(TMDB):
            xbmcaddon.Addon(TMDB).openSettings()
        else:
            xbmcgui.Dialog().ok(TITLE, 'TMDb Helper ist nicht installiert oder nicht aktiviert.')
    elif action == 'more':
        more()
    elif not action:
        if xbmc.getSkinDir() == 'skin.streamselect.home':
            xbmc.executebuiltin('ActivateWindow(Home)')
        else:
            index = xbmcgui.Dialog().select(TITLE, ['Kodi-Bibliothek öffnen', 'Kodi-Skin auswählen', 'Abbrechen'])
            if index == 0:
                from legacy import run
                run()
            elif index == 1:
                xbmc.executebuiltin('ActivateWindow(InterfaceSettings)')
    else:
        xbmcgui.Dialog().ok(TITLE, 'Unbekannte Aktion.')


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        xbmc.log('StreamSelect Home: %s' % error, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, 'Aktion fehlgeschlagen. Details stehen im Kodi-Protokoll.')
