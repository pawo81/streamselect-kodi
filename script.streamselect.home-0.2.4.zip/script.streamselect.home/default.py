# SPDX-License-Identifier: MIT
"""StreamSelect Home: deliberately small, standalone Kodi launcher."""
import json
import xbmc
import xbmcgui

TITLE = 'StreamSelect Home'
MENU = ['Start / zuletzt hinzugefügte Filme', 'Filme', 'Serien',
        'Kids (Bibliotheks-Tag Kids)', 'Merkliste / Kodi-Favoriten',
        'Suche in der lokalen Filmbibliothek', 'Installierte Video-Add-ons',
        'Information', 'Beenden']


def rpc(method, params):
    response = json.loads(xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    if 'error' in response:
        raise RuntimeError(response['error'].get('message', 'Kodi-Anfrage fehlgeschlagen'))
    return response.get('result', {})


def choose_movies(params, heading):
    movies = rpc('VideoLibrary.GetMovies', params).get('movies', [])
    if not movies:
        xbmcgui.Dialog().ok(TITLE, 'Keine passenden Filme in der Kodi-Bibliothek gefunden.')
        return False
    index = xbmcgui.Dialog().select(heading, [m.get('label', 'Film') for m in movies])
    if index < 0:
        return False
    rpc('Player.Open', {'item': {'movieid': movies[index]['movieid']}})
    return True


def video_addons():
    addons = rpc('Addons.GetAddons', {
        'type': 'xbmc.addon.video', 'enabled': True,
        'properties': ['name']}).get('addons', [])
    addons.sort(key=lambda item: item.get('name', item['addonid']).casefold())
    if not addons:
        xbmcgui.Dialog().ok(TITLE, 'Keine aktivierten Video-Add-ons vorhanden.')
        return False
    index = xbmcgui.Dialog().select('Installierte Video-Add-ons',
        [item.get('name', item['addonid']) for item in addons])
    if index < 0:
        return False
    rpc('Addons.ExecuteAddon', {'addonid': addons[index]['addonid']})
    return True


def run():
    while True:
        index = xbmcgui.Dialog().select(TITLE, MENU)
        if index < 0 or index == 8:
            return
        try:
            if index == 0:
                if choose_movies({'sort': {'method': 'dateadded', 'order': 'descending'},
                                  'limits': {'start': 0, 'end': 30}}, 'Zuletzt hinzugefügt'):
                    return
            elif index in (1, 2):
                path = 'videodb://movies/titles/' if index == 1 else 'videodb://tvshows/titles/'
                xbmc.executebuiltin('ActivateWindow(Videos,%s,return)' % path)
                return
            elif index == 3:
                if choose_movies({'filter': {'field': 'tag', 'operator': 'is', 'value': 'Kids'}},
                                 'Kids - ausdrücklich markierte Filme'):
                    return
            elif index == 4:
                xbmc.executebuiltin('ActivateWindow(Favourites)')
                return
            elif index == 5:
                query = xbmcgui.Dialog().input('Filmtitel suchen').strip()
                if query and choose_movies({'filter': {
                        'field': 'title', 'operator': 'contains', 'value': query}}, 'Suchergebnisse'):
                    return
            elif index == 6:
                if video_addons():
                    return
            elif index == 7:
                xbmcgui.Dialog().ok(TITLE,
                    'Neu erstellter Basis-Launcher 0.1.0. Kein Nimbus-Skin, keine Cover-Reihen, '
                    'keine Synchronisierung. Kids ist nur ein Tag-Filter für Filme, keine '
                    'Kindersicherung. Bedienung über die Dialoge des aktiven Kodi-Skins.')
        except Exception as error:
            xbmc.log('StreamSelect Home: %s' % error, xbmc.LOGERROR)
            xbmcgui.Dialog().ok(TITLE, 'Aktion fehlgeschlagen. Details stehen im Kodi-Protokoll.')


if __name__ == '__main__':
    run()
