"""Install explicitly selected video add-ons using Kodi's repository installer."""

import tempfile
from pathlib import Path

import xbmc
import xbmcgui
import xbmcvfs

from installer_core import InstallError, Transaction, contained, safe_extract

TITLE = "Optionale Video-Add-ons"
KUS = "repository.kus.allinone"
REPOSITORIES = {
    KUS: (
        "https://michaz1988.github.io/repo/repository.kus.allinone/repository.kus.allinone-3.8.zip",
        "945936da8bd817f53ba8e4e4b504419288a89a71bd3d9bd1ec258f7195a403f7",
    ),
    "repository.xvault": (
        "https://xvault.repowork.de/repository.xvault.zip",
        "af561ae789e375ed4f5bd3282dcb1ceec37e997f3731add7079b0cd73ede4c8c",
    ),
    "repository.dobbelina": (
        "https://dobbelina.github.io/repository.dobbelina-1.0.4.zip",
        "713d32a711905a64de538ba2da3e15950170cbb6bc10960e35d6f544db84238c",
    ),
}
ADDONS = (
    ("xStream", "plugin.video.xstream", KUS),
    ("xShip", "plugin.video.xship", KUS),
    ("xVAULT", "plugin.video.xvault", "repository.xvault"),
    ("Cumination (Erwachsene)", "plugin.video.cumination", "repository.dobbelina"),
)
MAX_ARCHIVE_BYTES = 4 * 1024 * 1024


def ensure_repository(repo_id, details, enable, rpc):
    if details(repo_id):
        enable(repo_id, "0", lambda: False)
        return
    if rpc("Settings.GetSettingValue", {"setting": "addons.unknownsources"}).get("value") is not True:
        raise InstallError("Bitte in Kodi zuerst „Unbekannte Quellen“ aktivieren.")

    url, expected_hash = REPOSITORIES[repo_id]
    addons_root = Path(xbmcvfs.translatePath("special://home/addons/")).resolve()
    target = contained(addons_root, addons_root / repo_id)
    if target.exists() or target.is_symlink():
        raise InstallError(f"Kodi konnte das vorhandene Repository {repo_id} nicht registrieren.")

    temporary_root = Path(xbmcvfs.translatePath("special://temp/"))
    temporary_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="streamselect-repo-", dir=temporary_root) as directory:
        work = Path(directory)
        handle = xbmcvfs.File(url)
        try:
            data = bytes(handle.readBytes(MAX_ARCHIVE_BYTES + 1))
        finally:
            handle.close()
        if not data or len(data) > MAX_ARCHIVE_BYTES:
            raise InstallError(f"Das Repository {repo_id} konnte nicht geladen werden.")
        archive = work / "repository.zip"
        archive.write_bytes(data)
        unpacked = work / "unpacked"
        safe_extract(archive, unpacked, expected_hash)
        source = unpacked / repo_id
        if not (source / "addon.xml").is_file():
            raise InstallError(f"Das ZIP enthält kein Add-on {repo_id}.")

        transaction = Transaction(work / "backup")
        transaction.apply([(repo_id, source, target)])
        try:
            xbmc.executebuiltin("UpdateLocalAddons", True)
            enable(repo_id, "0", lambda: False)
        except Exception:
            transaction.rollback()
            xbmc.executebuiltin("UpdateLocalAddons", True)
            raise
        transaction.commit()


def offer_extras(details, enable, rpc, *, quiet=False):
    dialog = xbmcgui.Dialog()
    choices = [entry for entry in ADDONS if not (details(entry[1]) or {}).get("enabled")]
    if not choices:
        if not quiet:
            dialog.ok(TITLE, "Alle angebotenen Add-ons sind bereits aktiv.")
        return
    selected = dialog.multiselect("Welche Video-Add-ons möchtest du hinzufügen?", [name for name, _, _ in choices])
    if not selected:
        return

    results = []
    ready_repositories = set()
    for index in selected:
        name, addon_id, repo_id = choices[index]
        try:
            if not details(addon_id):
                if repo_id not in ready_repositories:
                    ensure_repository(repo_id, details, enable, rpc)
                    # Reading the specific repository makes Kodi fetch its catalog when missing.
                    xbmcvfs.listdir(f"addons://{repo_id}/")
                    ready_repositories.add(repo_id)
                xbmc.executebuiltin(f"InstallAddon({addon_id})", True)
            if details(addon_id):
                enable(addon_id, "0", lambda: False)
                results.append(f"{name}: aktiv")
            else:
                results.append(f"{name}: nicht installiert")
        except Exception as error:
            xbmc.log(f"StreamSelect Installer: {name}: {error}", xbmc.LOGWARNING)
            results.append(f"{name}: {error}" if isinstance(error, InstallError) else f"{name}: Installation fehlgeschlagen")
    dialog.ok(TITLE, "\n".join(results))
