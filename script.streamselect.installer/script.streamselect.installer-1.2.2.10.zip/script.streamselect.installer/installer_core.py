"""Transactional file operations; independent of Kodi and platform."""
import hashlib
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import tempfile
import zipfile
from xml.etree import ElementTree as ET

class InstallError(Exception):
    pass

def version_key(value):
    return tuple(int(x) for x in re.findall(r'\d+', str(value).split('+',1)[0]))

def contained(root, candidate):
    original=Path(candidate).absolute()
    root, candidate = Path(root).resolve(), original.resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        raise InstallError('Ziel liegt ausserhalb des Add-on-Verzeichnisses.')
    return original

def safe_extract(archive_path, destination, sha256):
    data = Path(archive_path).read_bytes()
    if hashlib.sha256(data).hexdigest() != sha256:
        raise InstallError('Die Pruefsumme des Installationspakets stimmt nicht.')
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive_path) as archive:
        names=set()
        for info in archive.infolist():
            name=info.filename
            posix=PurePosixPath(name)
            mode=(info.external_attr >> 16) & 0o170000
            if (not name or '\\' in name or ':' in name or posix.is_absolute()
                    or '..' in posix.parts or mode==stat.S_IFLNK):
                raise InstallError('Ungueltiger Pfad im Installationspaket.')
            folded=name.casefold()
            if folded in names:
                raise InstallError('Doppelter Dateipfad im Installationspaket.')
            names.add(folded)
            contained(destination,destination.joinpath(*posix.parts))
        archive.extractall(destination)

def addon_metadata(directory):
    root=ET.parse(Path(directory)/'addon.xml').getroot()
    return {'id':root.get('id'),'version':root.get('version'),
            'requires':[(item.get('addon'),item.get('version','0'))
                        for item in root.findall('requires/import')
                        if item.get('optional')!='true']}

def build_plan(stage, addons_root, packages):
    plan=[]
    for package in packages:
        addon_id=package['id']
        if not re.fullmatch(r'[a-zA-Z0-9_.-]+',addon_id):
            raise InstallError('Ungueltige Add-on-ID.')
        source=contained(stage,Path(stage)/addon_id)
        target=contained(addons_root,Path(addons_root)/addon_id)
        meta=addon_metadata(source)
        if meta['id']!=addon_id or meta['version']!=package['version']:
            raise InstallError('Paketmanifest passt nicht zu '+addon_id)
        current=None
        if target.exists():
            current=addon_metadata(target)
            if current['id']!=addon_id:
                raise InstallError('Vorhandenes Add-on passt nicht zum Ziel.')
        primary=addon_id=='plugin.video.xstreamship'
        if primary and current and version_key(current['version'])>version_key(meta['version']):
            raise InstallError('Es ist bereits eine neuere StreamSelect-Version installiert.')
        minimum=package.get('minimum','0')
        needed=primary or not current or version_key(current['version'])<version_key(minimum)
        if target.is_symlink():
            raise InstallError('Verknuepfte Add-on-Ordner werden nicht ueberschrieben.')
        if needed:
            plan.append((addon_id,source,target))
    return plan

class Transaction:
    def __init__(self, backup_root):
        self.backup_root = Path(backup_root)
        self.changes = []
        self.committed = False

    def apply(self, plan, progress=lambda *_: None, cancelled=lambda: False):
        self.backup_root.mkdir(parents=True, exist_ok=False)
        try:
            for index, (addon_id, source, target) in enumerate(plan):
                if cancelled():
                    raise InstallError('Installation abgebrochen.')
                staging = Path(tempfile.mkdtemp(prefix='.streamselect-', dir=target.parent))
                try:
                    replacement = staging / 'replacement'
                    shutil.copytree(source, replacement)
                    backup = self.backup_root / addon_id if target.exists() else None
                    if backup is not None:
                        # If Windows holds a file open, leave the original directory intact.
                        target.rename(backup)
                    self.changes.append((target, backup, staging))
                except Exception:
                    shutil.rmtree(staging, ignore_errors=True)
                    raise
                replacement.rename(target)
                progress(index + 1, len(plan), addon_id)
        except Exception as error:
            try:
                self.rollback()
            except InstallError as rollback_error:
                raise InstallError(f'{error}\n{rollback_error}') from error
            raise

    def rollback(self):
        pending = []
        for target, backup, staging in reversed(self.changes):
            try:
                if target.exists():
                    target.rename(staging / 'rejected')
                if backup is not None:
                    backup.rename(target)
            except OSError:
                pending.append((target, backup, staging))
            else:
                shutil.rmtree(staging, ignore_errors=True)
        self.changes = list(reversed(pending))
        if pending:
            raise InstallError('Rücksicherung nicht vollständig. Sicherungen: ' + str(self.backup_root))

    def commit(self):
        self.committed = True
        for _, _, staging in self.changes:
            shutil.rmtree(staging, ignore_errors=True)
        self.changes.clear()
