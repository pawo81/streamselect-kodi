# -*- coding: utf-8 -*-
"""Local Kodi installer: bundled code only, profile data stays on the device."""
import json
from pathlib import Path
import shutil
import tempfile
import time
import uuid
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from installer_core import InstallError,Transaction,safe_extract,build_plan,version_key,contained

ADDON=xbmcaddon.Addon()
ROOT=Path(xbmcvfs.translatePath(ADDON.getAddonInfo('path')))
PROFILE=Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))
NAME='StreamSelect Installer'
HOME_SKIN='skin.streamselect.home'

def rpc(method,params=None):
    value=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':17,'method':method,'params':params or {}})))
    if 'error' in value:
        raise InstallError(value['error'].get('message','Kodi-Fehler'))
    return value.get('result',{})

def details(addon_id):
    try:
        return rpc('Addons.GetAddonDetails',{'addonid':addon_id,'properties':['enabled','version','name']})['addon']
    except (InstallError,KeyError):
        return None

def wait_until(predicate,seconds,cancelled):
    deadline=time.monotonic()+seconds
    monitor=xbmc.Monitor()
    while time.monotonic()<deadline:
        if cancelled() or monitor.abortRequested():
            raise InstallError('Installation abgebrochen.')
        result=predicate()
        if result:
            return result
        monitor.waitForAbort(0.2)
    raise InstallError('Kodi hat einen Installationsschritt nicht rechtzeitig bestaetigt.')

def enable(addon_id,minimum,cancelled):
    def registered():
        value=details(addon_id)
        return value if value and version_key(value.get('version','0'))>=version_key(minimum) else None
    value=wait_until(registered,30,cancelled)
    if not value.get('enabled'):
        rpc('Addons.SetAddonEnabled',{'addonid':addon_id,'enabled':True})
    wait_until(lambda:(details(addon_id) or {}).get('enabled'),15,cancelled)

def snapshot_profiles(profile_root,backup_root):
    entries=[('plugin.video.xstreamship','settings.xml'),
             ('plugin.video.themoviedb.helper','settings.xml'),
             ('plugin.video.themoviedb.helper','players'),
             ('plugin.video.themoviedb.helper','reconfigured_players')]
    records=[]
    for addon_id,name in entries:
        target=contained(profile_root,profile_root/addon_id/name)
        copy=backup_root/'profiles'/addon_id/name
        existed=target.exists()
        if existed:
            copy.parent.mkdir(parents=True,exist_ok=True)
            if target.is_dir():
                shutil.copytree(target,copy)
            else:
                shutil.copy2(target,copy)
        records.append((target,copy,existed))
    return records

def restore_profiles(records):
    for target,backup,existed in records:
        if target.is_dir():
            shutil.rmtree(target)
        elif target.exists():
            target.unlink()
        if existed:
            target.parent.mkdir(parents=True,exist_ok=True)
            if backup.is_dir():
                shutil.copytree(backup,target)
            else:
                shutil.copy2(backup,target)

def configure_region():
    warnings = []
    try:
        set_setting('locale.timezonecountry', 'Germany')
        set_setting('locale.timezone', 'Europe/Berlin')
    except InstallError:
        warnings.append('Zeitzone Europe/Berlin bitte in den Zeitzoneneinstellungen des Geräts prüfen.')

    language = 'resource.language.de_de'
    try:
        if not details(language):
            xbmc.executebuiltin('InstallAddon(' + language + ')')
        enable(language, '0', lambda: False)
        set_setting('locale.language', language)
    except InstallError:
        warnings.append('Deutsch konnte nicht aktiviert werden. Bitte das Sprachpaket im Kodi-Repository prüfen.')
    return warnings


def set_setting(setting, value):
    params = {'setting': setting}
    if rpc('Settings.GetSettingValue', params).get('value') != value:
        if rpc('Settings.SetSettingValue', dict(params, value=value)) is not True:
            raise InstallError('Kodi konnte ' + setting + ' nicht ändern.')
        if rpc('Settings.GetSettingValue', params).get('value') != value:
            raise InstallError('Kodi hat ' + setting + ' nicht übernommen.')


def install():
    if xbmc.Player().isPlaying():
        xbmcgui.Dialog().ok(NAME,'Bitte zuerst die laufende Wiedergabe beenden.')
        return
    version=rpc('Application.GetProperties',{'properties':['version']})['version']['major']
    if int(version)<21:
        xbmcgui.Dialog().ok(NAME,'Dieser Installer benoetigt Kodi 21 oder neuer.')
        return
    dialog=xbmcgui.DialogProgress()
    dialog.create(NAME,'Installationspaket wird geprueft ...')
    cancelled=dialog.iscanceled
    transaction=None
    profile_records=[]
    stage=None
    success=False
    try:
        manifest=json.loads((ROOT/'resources/manifest.json').read_text(encoding='utf-8'))
        addons_root=Path(xbmcvfs.translatePath('special://home/addons/')).resolve()
        profiles_root=Path(xbmcvfs.translatePath('special://profile/addon_data/')).resolve()
        addons_root.mkdir(parents=True,exist_ok=True)
        PROFILE.mkdir(parents=True,exist_ok=True)
        # Kodi installs native, platform-specific modules from its own repository.
        for item in manifest['external']:
            value=details(item['id'])
            if not value or version_key(value.get('version','0'))<version_key(item['minimum']):
                dialog.update(5,'Kodi installiert '+item['id']+' ...')
                xbmc.executebuiltin('InstallAddon('+item['id']+')')
                wait_until(lambda:details(item['id']) and version_key(details(item['id']).get('version','0'))>=version_key(item['minimum']),120,cancelled)
            enable(item['id'],item['minimum'],cancelled)
        temp_root=Path(xbmcvfs.translatePath('special://temp/')).resolve()
        temp_root.mkdir(parents=True,exist_ok=True)
        stage=Path(tempfile.mkdtemp(prefix='streamselect-',dir=str(temp_root)))
        safe_extract(ROOT/'resources/payload.zip',stage,manifest['sha256'])
        plan=build_plan(stage,addons_root,manifest['packages'])
        backup=PROFILE/'backups'/(time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8])
        transaction=Transaction(backup)
        transaction.apply(plan,lambda done,total,addon_id:dialog.update(10+int(done*55/max(1,total)),'Installiere '+addon_id),cancelled)
        profile_records=snapshot_profiles(profiles_root,backup)
        dialog.update(70,'Kodi registriert die Erweiterungen ...')
        xbmc.executebuiltin('UpdateLocalAddons')
        for package in manifest['packages']:
            enable(package['id'],package['minimum'],cancelled)
        dialog.update(90,'Player und Anbieter werden eingerichtet ...')
        token=uuid.uuid4().hex
        result_file=profiles_root/'plugin.video.xstreamship'/('install-result-'+token+'.json')
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.xstreamship/?action=finish_install&token='+token+')')
        wait_until(result_file.is_file,30,cancelled)
        result=json.loads(result_file.read_text(encoding='utf-8'))
        if result.get('token')!=token or not result.get('success'):
            raise InstallError(result.get('message','Die StreamSelect-Einrichtung ist fehlgeschlagen.'))
        result_file.unlink()
        transaction.commit()
        success=True
        (PROFILE/'last-install.json').write_text(json.dumps({'success':True,'version':manifest['version'],
            'backup':str(backup),'time':time.strftime('%Y-%m-%d %H:%M:%S')},ensure_ascii=False,indent=2),encoding='utf-8')
    except Exception as error:
        rollback_error=None
        if transaction and not transaction.committed:
            try:
                restore_profiles(profile_records)
                transaction.rollback()
                xbmc.executebuiltin('UpdateLocalAddons')
            except Exception as rollback:
                rollback_error=type(rollback).__name__
        dialog.close()
        message=str(error)
        if rollback_error:
            message+='\nRuecksicherung bitte pruefen: '+rollback_error
        xbmcgui.Dialog().ok(NAME,'Installation nicht abgeschlossen.\n\n'+message)
    finally:
        dialog.close()
        if stage and stage.exists():
            # Only remove the specific directory created by mkdtemp above.
            contained(Path(xbmcvfs.translatePath('special://temp/')),stage)
            shutil.rmtree(stage)
    if success:
        warnings = configure_region()
        xbmcgui.Dialog().ok(NAME,'StreamSelect ist installiert und eingerichtet.\n\nDie neuen Anbieter sind aktiviert. Filme und Serien verwenden StreamSelect als Standardplayer.\n\nStreamSelect Home wurde mitinstalliert.\n\nBitte Kodi vollstaendig neu starten. Danach kannst du StreamSelect Home unter Benutzeroberflaeche > Skin auswaehlen.' + ('\n\n' + '\n'.join(warnings) if warnings else ''))

def main():
    choice=xbmcgui.Dialog().select(NAME,['StreamSelect mit Home installieren / aktualisieren',
        'Installationsstatus anzeigen','StreamSelect oeffnen','Skin-Auswahl oeffnen'])
    if choice==0:
        install()
    elif choice==1:
        current=details('plugin.video.xstreamship')
        lines=['StreamSelect: '+(current.get('version','?') if current else 'nicht installiert')]
        for addon_id in ('plugin.video.themoviedb.helper','script.module.resolveurl',
                         'script.streamselect.home','script.streamselect.skinhelper',HOME_SKIN):
            value=details(addon_id)
            lines.append(addon_id+': '+(value.get('version','?') if value else 'fehlt'))
        xbmcgui.Dialog().textviewer(NAME,'\n'.join(lines))
    elif choice==2:
        if details('plugin.video.xstreamship'):
            xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.xstreamship/,return)')
        else:
            xbmcgui.Dialog().ok(NAME,'StreamSelect zuerst installieren.')

    elif choice==3:
        if (details(HOME_SKIN) or {}).get('enabled'):
            xbmc.executebuiltin('ActivateWindow(interfacesettings)')
        else:
            xbmcgui.Dialog().ok(NAME,'Bitte zuerst StreamSelect mit Home installieren.')

if __name__=='__main__':
    main()
